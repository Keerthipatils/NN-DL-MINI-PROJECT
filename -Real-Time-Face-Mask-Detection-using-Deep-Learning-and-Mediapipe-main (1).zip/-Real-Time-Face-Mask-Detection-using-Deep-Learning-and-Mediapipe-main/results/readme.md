# run the train_model.py and evaluate_model.py by running these two we see the results in graphs
